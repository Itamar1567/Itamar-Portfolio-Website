#ifndef INPUTVALIDATION_H
#define INPUTVALIDATION_H

#include <string>
using namespace std;

class InputValidation {

public:

    void ToLowerCase(string&);
    string convertInCodeNameToLowerCase(string);



private:





};

#endif // !INPUTVALIDATION_H
