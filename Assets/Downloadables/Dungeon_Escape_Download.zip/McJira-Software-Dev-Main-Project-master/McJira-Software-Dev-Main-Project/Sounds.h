#pragma once
#pragma once
#ifndef SOUNDS_H
#define SOUNDS_H
//Woah Woah Woah. If you are looking to add sounds please reference "Sounds.cpp" for more comprehensive directions
#include <string>
//function declaration for sounds. If you delete. CODE GO BOOM!!!!!
void playSound(const std::string& filename);

#endif