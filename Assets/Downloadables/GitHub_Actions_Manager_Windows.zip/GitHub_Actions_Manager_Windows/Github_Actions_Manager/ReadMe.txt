Purpose of this project

-This is a self learning project for myself to get familiar with REST API's and their usage
-This Project allows a user to modify their GitHub repositories status, view recent user activity's, and see user repositories (Requires a GitHub Account)

ps. if you need a GitHub token you get receive one from GitHub.com.
You may read this for more information on tokens: https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens

How To Download
1. Extract the zipped project folder
2. Open the "release" folder
3. Double click the .exe file

Functions

A user can input a GitHub username as an argument and receive the given user's recent activity, such as commits, commit messages, and commit URLs
A user can view and change the status of a given repository, provided an access token is given
A user can input a GitHub username as an argument and see all the given user's public repositories, or the user may provide a token and view the public and private repositories of the user whose token was given

✨ Features
🔑 Authenticate using a GitHub Personal Access Token
📦 Fetch all repositories for a given GitHub username
🔁 Change repository visibility between public and private
🧪 JSON validation and error handling

Included DLL's:

libcurl.dll: Enables sending HTTP requests to GitHub’s servers.

zlib1.dll: A dependency of libcurl, used for decompressing HTTP responses (e.g., gzip or deflate content from GitHub’s API).